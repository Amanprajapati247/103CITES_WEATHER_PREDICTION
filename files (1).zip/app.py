from flask import Flask, request, jsonify, send_from_directory
import joblib
import json
import numpy as np
from datetime import datetime
import os

app = Flask(__name__)

# Load models and data
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

rain_clf = joblib.load(os.path.join(BASE_DIR, 'rain_classifier.pkl'))
temp_reg = joblib.load(os.path.join(BASE_DIR, 'temp_regressor.pkl'))
wind_reg = joblib.load(os.path.join(BASE_DIR, 'wind_regressor.pkl'))
hum_reg  = joblib.load(os.path.join(BASE_DIR, 'humidity_regressor.pkl'))

with open(os.path.join(BASE_DIR, 'city_stats.json')) as f:
    city_stats = json.load(f)

with open(os.path.join(BASE_DIR, 'cities.json')) as f:
    cities = json.load(f)

@app.route('/')
def index():
    return send_from_directory(BASE_DIR, 'index.html')

@app.route('/api/cities')
def get_cities():
    return jsonify(cities)

@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.json
    city = data.get('city', '').strip().lower()
    date_str = data.get('date', '')
    hour = int(data.get('hour', 12))

    if city not in city_stats:
        return jsonify({'error': f'City "{city}" not found in dataset.'}), 404

    try:
        dt = datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD.'}), 400

    month = dt.month
    day_of_year = dt.timetuple().tm_yday

    c = city_stats[city]
    features = np.array([[
        c['city_enc'], month, day_of_year, hour,
        c['cloud_cover'], c['lifted_index'], c['relative_humidity'],
        c['wind_direction_enc'], c['wind_speed'], c['latitude'], c['longitude']
    ]])

    feature_names = ['city_enc', 'month', 'day_of_year', 'hour',
                     'cloud_cover', 'lifted_index', 'relative_humidity',
                     'wind_direction_enc', 'wind_speed', 'latitude', 'longitude']

    import pandas as pd
    features_df = pd.DataFrame(features, columns=feature_names)

    rain_pred   = int(rain_clf.predict(features_df)[0])
    rain_prob   = float(rain_clf.predict_proba(features_df)[0][1])
    temp_pred   = float(temp_reg.predict(features_df)[0])
    wind_pred   = float(wind_reg.predict(features_df)[0])
    hum_pred    = float(hum_reg.predict(features_df)[0])

    # Determine weather description
    if rain_prob > 0.6:
        condition = 'Heavy Rain Expected'
        icon = 'rainy'
    elif rain_prob > 0.3:
        condition = 'Light Rain Possible'
        icon = 'drizzle'
    elif hum_pred > 70:
        condition = 'Humid & Cloudy'
        icon = 'cloudy'
    elif temp_pred > 35:
        condition = 'Hot & Sunny'
        icon = 'sunny'
    elif temp_pred > 28:
        condition = 'Warm & Clear'
        icon = 'partly_cloudy'
    else:
        condition = 'Pleasant & Clear'
        icon = 'clear'

    return jsonify({
        'city': data.get('city'),
        'date': date_str,
        'will_rain': bool(rain_pred),
        'rain_probability': round(rain_prob * 100, 1),
        'temperature': round(temp_pred, 1),
        'wind_speed': round(wind_pred, 1),
        'humidity': round(hum_pred, 1),
        'condition': condition,
        'icon': icon,
        'latitude': c['latitude'],
        'longitude': c['longitude']
    })

if __name__ == '__main__':
    print("🌦️  Weather Prediction API running at http://localhost:5000")
    app.run(debug=True, port=5000)
