# Varsha — India Weather Intelligence 🌦

ML-powered weather prediction for 103 Indian cities.

## Project Structure
```
├── train_model.py         # ML model training script
├── app.py                 # Flask REST API backend
├── index.html             # Frontend (works standalone OR with backend)
├── rain_classifier.pkl    # Trained Random Forest Classifier
├── temp_regressor.pkl     # Temperature prediction model
├── wind_regressor.pkl     # Wind speed prediction model
├── humidity_regressor.pkl # Humidity prediction model
├── city_stats.json        # City feature statistics
├── cities.json            # List of 103 cities
└── india_weather_100cities_clean.csv  # Original dataset
```

## Models
| Model | Type | Performance |
|-------|------|-------------|
| Rain Classifier | Random Forest | 87.9% Accuracy |
| Temperature Regressor | Random Forest | 1.42°C MAE |
| Wind Speed Regressor | Random Forest | — |
| Humidity Regressor | Random Forest | — |

## How to Run

### Option 1: Open index.html directly in browser (no server needed)
The frontend has embedded prediction logic — just open `index.html` in any browser.

### Option 2: Run with Flask backend (full ML models)
```bash
pip install -r requirements.txt
python app.py
# Visit http://localhost:5000
```

## Input
- City name (103 Indian cities)
- Date
- Time of day

## Output
- 🌧 Rain/No Rain prediction
- Rain probability (%)
- 🌡 Temperature (°C)
- 💨 Wind speed (m/s)
- 💧 Humidity (%)
- Weather condition description
