import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, mean_absolute_error
import joblib
import json

# Load data
df = pd.read_csv('/home/claude/weather_data/india_weather_100cities_clean.csv')
print(f"Dataset shape: {df.shape}")
print(df.head(2))

# Feature engineering
df['init_time'] = pd.to_datetime(df['init_time'])
df['month'] = df['init_time'].dt.month
df['day_of_year'] = df['init_time'].dt.dayofyear
df['hour'] = df['timepoint_hr']

# Encode wind direction
wind_enc = LabelEncoder()
df['wind_direction_enc'] = wind_enc.fit_transform(df['wind_direction'])

# Encode city
city_enc = LabelEncoder()
df['city_enc'] = city_enc.fit_transform(df['city'])

# Create rain label (1 = rain, 0 = no rain)
df['will_rain'] = (df['precipitation_type'].isin(['rain', 'snow'])).astype(int)

print(f"\nRain distribution:\n{df['will_rain'].value_counts()}")

# Features for prediction
feature_cols = ['city_enc', 'month', 'day_of_year', 'hour', 
                'cloud_cover', 'lifted_index', 'relative_humidity',
                'wind_direction_enc', 'wind_speed', 'latitude', 'longitude']

X = df[feature_cols]
y_rain = df['will_rain']
y_temp = df['temperature_c']
y_wind = df['wind_speed']
y_humidity = df['relative_humidity']

# Train rain classifier
X_train, X_test, y_train, y_test = train_test_split(X, y_rain, test_size=0.2, random_state=42)
rain_clf = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
rain_clf.fit(X_train, y_train)
y_pred = rain_clf.predict(X_test)
print(f"\nRain prediction accuracy: {accuracy_score(y_test, y_pred):.3f}")

# Train temperature regressor
temp_reg = RandomForestRegressor(n_estimators=100, random_state=42)
temp_reg.fit(X_train, y_temp[X_train.index])
temp_pred = temp_reg.predict(X_test)
print(f"Temperature MAE: {mean_absolute_error(y_temp[X_test.index], temp_pred):.2f}°C")

# Train wind speed regressor
wind_reg = RandomForestRegressor(n_estimators=100, random_state=42)
wind_reg.fit(X_train, y_wind[X_train.index])

# Train humidity regressor  
hum_reg = RandomForestRegressor(n_estimators=100, random_state=42)
hum_reg.fit(X_train, y_humidity[X_train.index])

# Save models
joblib.dump(rain_clf, '/home/claude/rain_classifier.pkl')
joblib.dump(temp_reg, '/home/claude/temp_regressor.pkl')
joblib.dump(wind_reg, '/home/claude/wind_regressor.pkl')
joblib.dump(hum_reg, '/home/claude/humidity_regressor.pkl')
joblib.dump(city_enc, '/home/claude/city_encoder.pkl')
joblib.dump(wind_enc, '/home/claude/wind_encoder.pkl')

# Save city stats for lookup (lat, lon, avg cloud, lifted_index, humidity per city)
city_stats = df.groupby(['city', 'city_enc']).agg({
    'latitude': 'first',
    'longitude': 'first',
    'cloud_cover': 'mean',
    'lifted_index': 'mean',
    'relative_humidity': 'mean',
    'wind_direction_enc': lambda x: x.mode()[0],
    'wind_speed': 'mean'
}).reset_index()

city_stats_dict = {}
for _, row in city_stats.iterrows():
    city_stats_dict[row['city'].lower()] = {
        'city_enc': int(row['city_enc']),
        'latitude': float(row['latitude']),
        'longitude': float(row['longitude']),
        'cloud_cover': float(row['cloud_cover']),
        'lifted_index': float(row['lifted_index']),
        'relative_humidity': float(row['relative_humidity']),
        'wind_direction_enc': float(row['wind_direction_enc']),
        'wind_speed': float(row['wind_speed'])
    }

with open('/home/claude/city_stats.json', 'w') as f:
    json.dump(city_stats_dict, f, indent=2)

# Save city list
cities = sorted(df['city'].unique().tolist())
with open('/home/claude/cities.json', 'w') as f:
    json.dump(cities, f)

print(f"\nSaved {len(city_stats_dict)} cities")
print("All models saved successfully!")

# Test prediction
def predict_weather(city_name, month, day_of_year, hour=12):
    city_data = city_stats_dict.get(city_name.lower())
    if not city_data:
        return None
    
    features = [[
        city_data['city_enc'], month, day_of_year, hour,
        city_data['cloud_cover'], city_data['lifted_index'],
        city_data['relative_humidity'], city_data['wind_direction_enc'],
        city_data['wind_speed'], city_data['latitude'], city_data['longitude']
    ]]
    
    rain = rain_clf.predict(features)[0]
    rain_prob = rain_clf.predict_proba(features)[0][1]
    temp = temp_reg.predict(features)[0]
    wind = wind_reg.predict(features)[0]
    humidity = hum_reg.predict(features)[0]
    
    return {
        'will_rain': bool(rain),
        'rain_probability': float(rain_prob),
        'temperature': float(temp),
        'wind_speed': float(wind),
        'humidity': float(humidity)
    }

# Test
result = predict_weather('Mumbai', month=7, day_of_year=196, hour=12)
print(f"\nTest prediction for Mumbai (July):\n{result}")

result2 = predict_weather('Delhi', month=1, day_of_year=15, hour=12)
print(f"\nTest prediction for Delhi (January):\n{result2}")
